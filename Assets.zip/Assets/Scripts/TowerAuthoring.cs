﻿using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

public enum TowerRangeType
{
    Default,      // 일반 원형
    Sector,       // 부채꼴 (각도)
    Annulus,      // 동심원 (최소 사거리)
    OffsetCircle  // 중심점 이동
}

public class TowerAuthoring : MonoBehaviour
{
    [Header("Basic Stats")]
    public float Damage = 10f;
    public float AttackSpeed = 1f;
    public TowerRangeType RangeType = TowerRangeType.Default;

    [Header("Range Config (Fill only what's needed)")]
    public float MaxRange = 5f;
    public float MinRange = 0f;    // Annulus용
    public float RangeAngle = 360f; // Sector용
    public Vector3 RangeOffset;    // Offset용

    [Header("Attack Visuals")]
    public GameObject BulletPrefab;    // 생성할 탄환
    public GameObject ExplosionVFX;    // 탄환이 터질 때 쓸 효과

    public class TowerBaker : Baker<TowerAuthoring>
    {
        public override void Bake(TowerAuthoring authoring)
        {
            Entity entity = GetEntity(TransformUsageFlags.Dynamic);

            AddComponent(entity, new PickingIdColor());

            float dmg = authoring.Damage;
            float spd = authoring.AttackSpeed;
            float maxR = authoring.MaxRange;
            float minR = authoring.MinRange;

            TowerData data = new TowerData
            {
                Damage = dmg,
                AttackSpeed = spd,
                RangeType = authoring.RangeType,
                MaxRange = maxR,
                MinRange = minR,
                RangeAngle = authoring.RangeAngle,
                RangeOffset = authoring.RangeOffset,

                // BulletPrefab과 ExplosionVFX를 엔티티로 변환하여 주입
                BulletPrefab = GetEntity(authoring.BulletPrefab, TransformUsageFlags.Dynamic),
                ExplosionPrefab = GetEntity(authoring.ExplosionVFX, TransformUsageFlags.Dynamic),

                TargetMonster = Entity.Null,
                AttackTimer = 0f
            };

            AddComponent(entity, data);
        }
    }
}

public struct TowerData : IComponentData
{
    // --- Stats (불변/설정값) ---
    public float Damage;
    public float AttackSpeed;
    public float MaxRange;
    public float MinRange;
    public float RangeAngle;
    public float3 RangeOffset;
    public TowerRangeType RangeType;

    // --- Assets (참조) ---
    public Entity BulletPrefab;    // 탄환 엔티티 프리팹
    public Entity ExplosionPrefab; // 탄환이 터질 때 쓸 효과 프리팹

    // --- Runtime States (가변값) ---
    public Entity TargetMonster;
    public float AttackTimer;
}